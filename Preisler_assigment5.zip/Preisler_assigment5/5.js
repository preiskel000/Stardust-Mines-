var x = 200;

var y = 200;

var radius = 15;

let button;

function setup() {
  createCanvas(400, 400); 
  
ellipseMode (RADIUS);
  
	ellipse(x, y, radius, radius);
  
   button = createButton('J/K');
  button.position(280, 350);
  button.mousePressed(changeBG);
   
       function changeBG() {
  let val = random(255);
  background(val);
}
  
}

function draw() {
  
  background(220);
 fill( 31, 44, 64);
rect(50,70,300,300);
  fill(62,87,128);
  rect(75,80,250,250);
  ellipse(250, 350, 15, 15);
ellipse (150, 350, 15, 15) ;
ellipse ( 200, 350, 15, 15);
  
  var d = dist(mouseX, mouseY, x, y);
if (keyIsPressed) {
if (key == 'x') {
if (d < radius) {
 radius++;
fill(125, 175, 225);
} else {
  fill (255);
  
			}
}
  
  
}
 ellipse(x, y, radius, radius);
  
  if (keyIsPressed) {
   if (key == 'j') {
  fill(112,157,230)
 ellipse(200,200,50,50)
     } else {
  fill (255);
			}
  } 
   if (keyIsPressed) {
   if (key == 'k') {
  
      fill(96,134,194);
 ellipse(200,200,80,80)
     } else {
  fill (255);
}

   } 
}