function setup() {
  createCanvas(400,400, WEBGL);
  
}

let angle = 0;
function draw() {
  background(220);
  for (var i = -120; i < 140; i += 40) {
  	line(i, 80, i + 30, 100);}
  for (var i = -120; i < 140; i += 50) {
  	line(i, 120, i + 20, 100);
  } 
   push()
  rect(30, 20, 50, 50);
scale(0.5);
rect(30, 20, 50, 50);
  rect(30, 20, 50, 50);
scale(0.5);
rect(30, 20, 50, 50);
 pop()
  
  push()
  rect(25, -100, 80, 80);
scale(0.5);
rect(100, -270, 90, 90);
  rect(30, 20, 50, 50);
scale(0.5);
rect(120, -590, 100, 100);
 pop()
 
 push()
  rect(-100, -150, 80, 80);
scale(0.5);
rect(-180, -200, 300, 300);
  rect(30, 20, 50, 50);
scale(0.5);
rect(-450, 10, 300, 300);
 pop()
  
  fill(132,142,129)
  rect(150, 185,-300, -380)
  fill(78, 128,62)
  rect(120, 80, -240, -255)
  ellipse (90, 130, -25,-25)
  fill(148,25,9)
  ellipse (70, 160, -25, -25)
  fill(18,64,148)
  ellipse (40, 140, -25, -25)
  fill(225,223,97)
  ellipse(60, 110, -25,-25)
   push()
  translate(width / -3, height / -2);
  translate(p5.Vector.fromAngle(millis() / 1000, 90));
 rect(110,140,50,50)
   pop()
  
  push()
 translate(width /   -80, height / -9);
 rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  box(100, 100, 100, 4, 4);
  stroke(5);
  pop()
  
  
  angleMode(DEGREES); 
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  //translate(width / 2, height / 2);
  translate(-20, 150);
  push();
  rotate(a);
  rect( 0, 5, 40, 10); 
  angleMode(RADIANS); 
  rotate(a); 
  rect( 20, 5, 20, 10); 
 
  
let x = 10;
print('The value of x is ' + x);
  
   }