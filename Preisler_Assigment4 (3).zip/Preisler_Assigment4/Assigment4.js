let yPos = 0;

function setup() {
  createCanvas(400, 400); 
 strokeWeight(4); 
  frameRate(30);
}
let value = 0;
function draw(){
  background (200);
  
   yPos = yPos - 2;
  if (yPos < 201) {
    yPos = 400;
  }
  line(0, yPos, width, yPos);
  
   fill(9,48,4);
  rect(1,350,400,100);
  
   for (var i = 20; i < 75; i +=2) { 
    line(i, 400, i + 200, 350); 
}
  
  for (var i = 20; i < 400; i += 51) 
  	line(i, 350, i + 0, 200);
  
  if (keyIsPressed === true) {
    fill(241, 194, 19);
  } else {
    fill(241, 227, 19);
  }
  ellipse (340,90,100,100);
  
  fill(value); 
  rect(224,229,50,120); 
}
function mousePressed(){ 
  if (value === 0){
    value = 225;{ 
  }
  } else { 
    
    value  = 0; 
  }

}

  
  